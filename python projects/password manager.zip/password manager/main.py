from tkinter import *
import random
from tkinter import messagebox
import pyperclip

# ----------Generate password----------#


def generate_password():

    password_entry.delete(0, END)

    small_letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
                     'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']

    large_letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
                     'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']

    numbers = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0']

    symbols = ['/', '!', '@', '#', '$', '*', '.']

    nr_small_letters = random.randint(4, 6)
    nr_large_letters = random.randint(1, 3)
    nr_numbers = random.randint(1, 3)
    nr_symbols = random.randint(1, 3)

    password_list = []

    for n in range(nr_small_letters):
        password_list.append(random.choice(small_letters))

    for n in range(nr_large_letters):
        password_list.append(random.choice(large_letters))

    for n in range(nr_numbers):
        password_list.append(random.choice(numbers))

    for n in range(nr_symbols):
        password_list.append(random.choice(symbols))

    random.shuffle(password_list)
    jointed_password = "".join(password_list)
    print(jointed_password)

    password_entry.insert(0, jointed_password)

    pyperclip.copy(jointed_password)


# ----------Save data----------#

def save_data():

    website_data = webname_entry.get()
    username_data = username_entry.get()
    password_data = password_entry.get()

    if len(website_data) == 0 or len(username_data) == 0 or len(password_data) == 0:
        messagebox.showinfo(message="Opps!\nDon't leave any field empty")
    else:
        is_ok = messagebox.askokcancel(title=website_data, message=f"These are the details entered\n"
                                                                   f"Website: {website_data}\n"
                                                                   f"Email: {username_data}\n"
                                                                   f"Password: {password_data}")
        if is_ok:
            with open("data.txt", "a") as data_file:
                data_file.write(f"{website_data}:-[Username/Email: {username_data} | password: {password_data}]\n")
                webname_entry.delete(0, END)
                password_entry.delete(0, END)
                username_entry.delete(0, END)


# ----------UI setup----------#
window = Tk()
window.title("Password manager")
canvas = Canvas(height=200, width=200)
window.config(pady=40, padx=60)

logoimg = PhotoImage(file="logo.png")
canvas.create_image(100, 100, image=logoimg)
canvas.grid(row=0, column=1)


# ---Labels---#

website = Label(text="Website:")
website.grid(row=1, column=0)

username = Label(text="Email/Username:")
username.grid(row=2, column=0)

password = Label(text="Password:")
password.grid(row=3, column=0)

# ---Entries---#

webname_entry = Entry(width=39)
webname_entry.grid(row=1, column=1, columnspan=2)
webname_entry.focus()

username_entry = Entry(width=39)
username_entry.grid(row=2, column=1, columnspan=2)

password_entry = Entry(width=22)
password_entry.grid(row=3, column=1)

# ---Buttons---#

generate_pass = Button(text="Generate password", command=generate_password)
generate_pass.grid(row=3, column=2)

save = Button(text="Save", width=36, command=save_data)
save.grid(row=4, column=1, columnspan=2)

window.mainloop()



